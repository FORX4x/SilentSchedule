package com.example.silentschedule

import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var switchEnable: SwitchMaterial
    private lateinit var btnStart: MaterialButton
    private lateinit var btnEnd: MaterialButton
    private lateinit var btnGrant: MaterialButton
    private lateinit var txtStatus: TextView
    private lateinit var txtPermission: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        switchEnable = findViewById(R.id.switchEnable)
        btnStart = findViewById(R.id.btnStart)
        btnEnd = findViewById(R.id.btnEnd)
        btnGrant = findViewById(R.id.btnGrant)
        txtStatus = findViewById(R.id.txtStatus)
        txtPermission = findViewById(R.id.txtPermission)

        switchEnable.isChecked = Prefs.enabled(this)

        switchEnable.setOnCheckedChangeListener { _, checked ->
            if (checked && Prefs.startMinutes(this) == Prefs.endMinutes(this)) {
                Toast.makeText(this, R.string.same_time, Toast.LENGTH_LONG).show()
                switchEnable.isChecked = false
                return@setOnCheckedChangeListener
            }
            Prefs.setEnabled(this, checked)
            if (checked && !Silencer.hasAccess(this)) openPolicySettings()
            Scheduler.refresh(this)
            render()
        }

        btnStart.setOnClickListener {
            pickTime(Prefs.startMinutes(this)) { Prefs.setStartMinutes(this, it) }
        }
        btnEnd.setOnClickListener {
            pickTime(Prefs.endMinutes(this)) { Prefs.setEndMinutes(this, it) }
        }
        btnGrant.setOnClickListener { openPolicySettings() }
    }

    override fun onResume() {
        super.onResume()
        // The user may have just granted access in system settings.
        Scheduler.refresh(this)
        render()
    }

    private fun pickTime(current: Int, save: (Int) -> Unit) {
        TimePickerDialog(this, { _, h, m ->
            save(h * 60 + m)
            if (Prefs.startMinutes(this) == Prefs.endMinutes(this)) {
                Toast.makeText(this, R.string.same_time, Toast.LENGTH_LONG).show()
            }
            Scheduler.refresh(this)
            render()
        }, current / 60, current % 60, true).show()
    }

    private fun openPolicySettings() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
    }

    private fun fmt(minutes: Int) = String.format("%02d:%02d", minutes / 60, minutes % 60)

    private fun render() {
        val start = Prefs.startMinutes(this)
        val end = Prefs.endMinutes(this)
        btnStart.text = fmt(start)
        btnEnd.text = fmt(end)

        txtStatus.text = if (Prefs.enabled(this)) {
            getString(R.string.status_on, fmt(start), fmt(end))
        } else {
            getString(R.string.status_off)
        }

        val ok = Silencer.hasAccess(this)
        txtPermission.setText(if (ok) R.string.perm_ok else R.string.perm_missing)
        btnGrant.visibility = if (ok) android.view.View.GONE else android.view.View.VISIBLE
    }
}
