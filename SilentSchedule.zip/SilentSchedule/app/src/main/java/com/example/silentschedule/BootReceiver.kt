package com.example.silentschedule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restores alarms after reboot, app update, or a clock/time-zone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.refresh(context)
    }
}
