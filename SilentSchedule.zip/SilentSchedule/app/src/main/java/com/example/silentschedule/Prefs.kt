package com.example.silentschedule

import android.content.Context

/** Simple storage. Times are kept as minutes since midnight. */
object Prefs {
    private fun sp(c: Context) =
        c.getSharedPreferences("silent_schedule", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun startMinutes(c: Context) = sp(c).getInt("start", 23 * 60)
    fun setStartMinutes(c: Context, v: Int) = sp(c).edit().putInt("start", v).apply()

    fun endMinutes(c: Context) = sp(c).getInt("end", 7 * 60)
    fun setEndMinutes(c: Context, v: Int) = sp(c).edit().putInt("end", v).apply()

    /** True while this app is the one holding the phone silent. */
    fun applied(c: Context) = sp(c).getBoolean("applied", false)
    fun setApplied(c: Context, v: Boolean) = sp(c).edit().putBoolean("applied", v).apply()

    fun savedMode(c: Context) = sp(c).getInt("saved_mode", -1)
    fun setSavedMode(c: Context, v: Int) = sp(c).edit().putInt("saved_mode", v).apply()
}
