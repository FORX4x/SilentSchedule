package com.example.silentschedule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Scheduler.ACTION_START -> Silencer.silence(context)
            Scheduler.ACTION_END -> Silencer.restore(context)
        }
        // Schedule the next day's alarms.
        Scheduler.refresh(context)
    }
}
