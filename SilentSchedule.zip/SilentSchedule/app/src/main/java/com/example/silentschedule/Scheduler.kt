package com.example.silentschedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    const val ACTION_START = "com.example.silentschedule.START"
    const val ACTION_END = "com.example.silentschedule.END"

    private const val CODE_START = 1
    private const val CODE_END = 2

    /** Re-creates the alarms from the saved settings and syncs the phone state. */
    fun refresh(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pending(c, ACTION_START, CODE_START))
        am.cancel(pending(c, ACTION_END, CODE_END))

        if (Prefs.enabled(c) && Prefs.startMinutes(c) != Prefs.endMinutes(c)) {
            setAlarm(c, am, ACTION_START, CODE_START, Prefs.startMinutes(c))
            setAlarm(c, am, ACTION_END, CODE_END, Prefs.endMinutes(c))
        }
        Silencer.sync(c)
    }

    private fun pending(c: Context, action: String, code: Int): PendingIntent {
        val intent = Intent(c, AlarmReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            c, code, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun setAlarm(c: Context, am: AlarmManager, action: String, code: Int, minutes: Int) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minutes / 60)
            set(Calendar.MINUTE, minutes % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1)
        }
        val showIntent = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        // setAlarmClock is exact, survives Doze, and needs no extra permission.
        am.setAlarmClock(
            AlarmManager.AlarmClockInfo(cal.timeInMillis, showIntent),
            pending(c, action, code)
        )
    }
}
