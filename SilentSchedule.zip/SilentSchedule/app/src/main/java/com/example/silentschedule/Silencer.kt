package com.example.silentschedule

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import java.util.Calendar

object Silencer {

    fun hasAccess(c: Context): Boolean {
        val nm = c.getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted
    }

    fun silence(c: Context) {
        if (!hasAccess(c)) return
        val am = c.getSystemService(AudioManager::class.java)
        if (!Prefs.applied(c)) {
            Prefs.setSavedMode(c, am.ringerMode)
            Prefs.setApplied(c, true)
        }
        am.ringerMode = AudioManager.RINGER_MODE_SILENT
    }

    fun restore(c: Context) {
        if (!Prefs.applied(c)) return
        if (hasAccess(c)) {
            val saved = Prefs.savedMode(c)
            if (saved >= 0) {
                val am = c.getSystemService(AudioManager::class.java)
                am.ringerMode = saved
            }
        }
        Prefs.setApplied(c, false)
    }

    fun isInWindow(c: Context, nowMinutes: Int): Boolean {
        val start = Prefs.startMinutes(c)
        val end = Prefs.endMinutes(c)
        return when {
            start == end -> false
            start < end -> nowMinutes in start until end
            else -> nowMinutes >= start || nowMinutes < end // crosses midnight
        }
    }

    /** Makes the phone match the schedule right now. */
    fun sync(c: Context) {
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        if (Prefs.enabled(c) && isInWindow(c, now)) silence(c) else restore(c)
    }
}
